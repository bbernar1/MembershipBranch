﻿namespace JGMSNewMemberSignup
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.newMembership = new System.Windows.Forms.TabPage();
            this.newPerson = new System.Windows.Forms.TabPage();
            this.lbl01 = new System.Windows.Forms.Label();
            this.lbl02 = new System.Windows.Forms.Label();
            this.lbl03 = new System.Windows.Forms.Label();
            this.lbl04 = new System.Windows.Forms.Label();
            this.lbl05 = new System.Windows.Forms.Label();
            this.lbl06 = new System.Windows.Forms.Label();
            this.lbl07 = new System.Windows.Forms.Label();
            this.lbl08 = new System.Windows.Forms.Label();
            this.dueMeetingReport = new System.Windows.Forms.TabPage();
            this.meetingReport = new System.Windows.Forms.TabPage();
            this.rosterReport = new System.Windows.Forms.TabPage();
            this.lbl09 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.lbl11 = new System.Windows.Forms.Label();
            this.txtBx01 = new System.Windows.Forms.TextBox();
            this.txtBx02 = new System.Windows.Forms.TextBox();
            this.txtBx03 = new System.Windows.Forms.TextBox();
            this.txtBx04 = new System.Windows.Forms.TextBox();
            this.txtBx05 = new System.Windows.Forms.TextBox();
            this.txtBx06 = new System.Windows.Forms.TextBox();
            this.chkBx01 = new System.Windows.Forms.CheckBox();
            this.chkBx02 = new System.Windows.Forms.CheckBox();
            this.chkBx03 = new System.Windows.Forms.CheckBox();
            this.comboBox01 = new System.Windows.Forms.ComboBox();
            this.comboBox02 = new System.Windows.Forms.ComboBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl16 = new System.Windows.Forms.Label();
            this.lbl17 = new System.Windows.Forms.Label();
            this.lbl18 = new System.Windows.Forms.Label();
            this.lbl19 = new System.Windows.Forms.Label();
            this.lbl20 = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.lbl23 = new System.Windows.Forms.Label();
            this.lbl24 = new System.Windows.Forms.Label();
            this.lbl25 = new System.Windows.Forms.Label();
            this.txtBx07 = new System.Windows.Forms.TextBox();
            this.txtBx08 = new System.Windows.Forms.TextBox();
            this.txtBx09 = new System.Windows.Forms.TextBox();
            this.txtBx10 = new System.Windows.Forms.TextBox();
            this.txtBx11 = new System.Windows.Forms.TextBox();
            this.txtBx12 = new System.Windows.Forms.TextBox();
            this.txtBx13 = new System.Windows.Forms.TextBox();
            this.txtBx14 = new System.Windows.Forms.TextBox();
            this.txtBx16 = new System.Windows.Forms.TextBox();
            this.txtBx15 = new System.Windows.Forms.TextBox();
            this.checkBox04 = new System.Windows.Forms.CheckBox();
            this.checkBox05 = new System.Windows.Forms.CheckBox();
            this.comboBox03 = new System.Windows.Forms.ComboBox();
            this.comboBox04 = new System.Windows.Forms.ComboBox();
            this.tabControl1.SuspendLayout();
            this.newMembership.SuspendLayout();
            this.newPerson.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.newMembership);
            this.tabControl1.Controls.Add(this.newPerson);
            this.tabControl1.Controls.Add(this.dueMeetingReport);
            this.tabControl1.Controls.Add(this.meetingReport);
            this.tabControl1.Controls.Add(this.rosterReport);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(550, 410);
            this.tabControl1.TabIndex = 0;
            // 
            // newMembership
            // 
            this.newMembership.Controls.Add(this.btnSubmit);
            this.newMembership.Controls.Add(this.comboBox02);
            this.newMembership.Controls.Add(this.comboBox01);
            this.newMembership.Controls.Add(this.chkBx03);
            this.newMembership.Controls.Add(this.chkBx02);
            this.newMembership.Controls.Add(this.chkBx01);
            this.newMembership.Controls.Add(this.txtBx06);
            this.newMembership.Controls.Add(this.txtBx05);
            this.newMembership.Controls.Add(this.txtBx04);
            this.newMembership.Controls.Add(this.txtBx03);
            this.newMembership.Controls.Add(this.txtBx02);
            this.newMembership.Controls.Add(this.txtBx01);
            this.newMembership.Controls.Add(this.lbl11);
            this.newMembership.Controls.Add(this.lbl10);
            this.newMembership.Controls.Add(this.lbl09);
            this.newMembership.Controls.Add(this.lbl08);
            this.newMembership.Controls.Add(this.lbl07);
            this.newMembership.Controls.Add(this.lbl06);
            this.newMembership.Controls.Add(this.lbl05);
            this.newMembership.Controls.Add(this.lbl04);
            this.newMembership.Controls.Add(this.lbl03);
            this.newMembership.Controls.Add(this.lbl02);
            this.newMembership.Controls.Add(this.lbl01);
            this.newMembership.Location = new System.Drawing.Point(4, 22);
            this.newMembership.Name = "newMembership";
            this.newMembership.Padding = new System.Windows.Forms.Padding(3);
            this.newMembership.Size = new System.Drawing.Size(542, 384);
            this.newMembership.TabIndex = 0;
            this.newMembership.Text = "New Membership";
            this.newMembership.UseVisualStyleBackColor = true;
            // 
            // newPerson
            // 
            this.newPerson.Controls.Add(this.comboBox04);
            this.newPerson.Controls.Add(this.comboBox03);
            this.newPerson.Controls.Add(this.checkBox05);
            this.newPerson.Controls.Add(this.checkBox04);
            this.newPerson.Controls.Add(this.txtBx15);
            this.newPerson.Controls.Add(this.txtBx16);
            this.newPerson.Controls.Add(this.txtBx14);
            this.newPerson.Controls.Add(this.txtBx13);
            this.newPerson.Controls.Add(this.txtBx12);
            this.newPerson.Controls.Add(this.txtBx11);
            this.newPerson.Controls.Add(this.txtBx10);
            this.newPerson.Controls.Add(this.txtBx09);
            this.newPerson.Controls.Add(this.txtBx08);
            this.newPerson.Controls.Add(this.txtBx07);
            this.newPerson.Controls.Add(this.lbl25);
            this.newPerson.Controls.Add(this.lbl24);
            this.newPerson.Controls.Add(this.lbl23);
            this.newPerson.Controls.Add(this.lbl22);
            this.newPerson.Controls.Add(this.lbl21);
            this.newPerson.Controls.Add(this.lbl20);
            this.newPerson.Controls.Add(this.lbl19);
            this.newPerson.Controls.Add(this.lbl18);
            this.newPerson.Controls.Add(this.lbl17);
            this.newPerson.Controls.Add(this.lbl16);
            this.newPerson.Controls.Add(this.lbl15);
            this.newPerson.Controls.Add(this.lbl14);
            this.newPerson.Controls.Add(this.lbl13);
            this.newPerson.Controls.Add(this.lbl12);
            this.newPerson.Location = new System.Drawing.Point(4, 22);
            this.newPerson.Name = "newPerson";
            this.newPerson.Padding = new System.Windows.Forms.Padding(3);
            this.newPerson.Size = new System.Drawing.Size(542, 384);
            this.newPerson.TabIndex = 1;
            this.newPerson.Text = "New Person";
            this.newPerson.UseVisualStyleBackColor = true;
            // 
            // lbl01
            // 
            this.lbl01.AutoSize = true;
            this.lbl01.Location = new System.Drawing.Point(21, 31);
            this.lbl01.Name = "lbl01";
            this.lbl01.Size = new System.Drawing.Size(78, 13);
            this.lbl01.TabIndex = 0;
            this.lbl01.Text = "Membership ID";
            this.lbl01.Click += new System.EventHandler(this.lbl1_Click);
            // 
            // lbl02
            // 
            this.lbl02.AutoSize = true;
            this.lbl02.Location = new System.Drawing.Point(21, 54);
            this.lbl02.Name = "lbl02";
            this.lbl02.Size = new System.Drawing.Size(91, 13);
            this.lbl02.TabIndex = 1;
            this.lbl02.Text = "Membership Type";
            this.lbl02.Click += new System.EventHandler(this.lbl2_Click);
            // 
            // lbl03
            // 
            this.lbl03.AutoSize = true;
            this.lbl03.Location = new System.Drawing.Point(21, 80);
            this.lbl03.Name = "lbl03";
            this.lbl03.Size = new System.Drawing.Size(88, 13);
            this.lbl03.TabIndex = 2;
            this.lbl03.Text = "Number of Adults";
            // 
            // lbl04
            // 
            this.lbl04.AutoSize = true;
            this.lbl04.Location = new System.Drawing.Point(21, 104);
            this.lbl04.Name = "lbl04";
            this.lbl04.Size = new System.Drawing.Size(78, 13);
            this.lbl04.TabIndex = 3;
            this.lbl04.Text = "Liability Waiver";
            // 
            // lbl05
            // 
            this.lbl05.AutoSize = true;
            this.lbl05.Location = new System.Drawing.Point(21, 130);
            this.lbl05.Name = "lbl05";
            this.lbl05.Size = new System.Drawing.Size(116, 13);
            this.lbl05.TabIndex = 4;
            this.lbl05.Text = "Confidential Agreement";
            // 
            // lbl06
            // 
            this.lbl06.AutoSize = true;
            this.lbl06.Location = new System.Drawing.Point(21, 153);
            this.lbl06.Name = "lbl06";
            this.lbl06.Size = new System.Drawing.Size(85, 13);
            this.lbl06.TabIndex = 5;
            this.lbl06.Text = "Newsletter Email";
            // 
            // lbl07
            // 
            this.lbl07.AutoSize = true;
            this.lbl07.Location = new System.Drawing.Point(21, 185);
            this.lbl07.Name = "lbl07";
            this.lbl07.Size = new System.Drawing.Size(35, 13);
            this.lbl07.TabIndex = 6;
            this.lbl07.Text = "Street";
            // 
            // lbl08
            // 
            this.lbl08.AutoSize = true;
            this.lbl08.Location = new System.Drawing.Point(21, 211);
            this.lbl08.Name = "lbl08";
            this.lbl08.Size = new System.Drawing.Size(24, 13);
            this.lbl08.TabIndex = 7;
            this.lbl08.Text = "City";
            // 
            // dueMeetingReport
            // 
            this.dueMeetingReport.Location = new System.Drawing.Point(4, 22);
            this.dueMeetingReport.Name = "dueMeetingReport";
            this.dueMeetingReport.Size = new System.Drawing.Size(542, 384);
            this.dueMeetingReport.TabIndex = 2;
            this.dueMeetingReport.Text = "Due Meeting Report";
            this.dueMeetingReport.UseVisualStyleBackColor = true;
            // 
            // meetingReport
            // 
            this.meetingReport.Location = new System.Drawing.Point(4, 22);
            this.meetingReport.Name = "meetingReport";
            this.meetingReport.Size = new System.Drawing.Size(542, 321);
            this.meetingReport.TabIndex = 3;
            this.meetingReport.Text = "Meeting Report";
            this.meetingReport.UseVisualStyleBackColor = true;
            // 
            // rosterReport
            // 
            this.rosterReport.Location = new System.Drawing.Point(4, 22);
            this.rosterReport.Name = "rosterReport";
            this.rosterReport.Size = new System.Drawing.Size(542, 321);
            this.rosterReport.TabIndex = 4;
            this.rosterReport.Text = "Roster Report";
            this.rosterReport.UseVisualStyleBackColor = true;
            // 
            // lbl09
            // 
            this.lbl09.AutoSize = true;
            this.lbl09.Location = new System.Drawing.Point(21, 238);
            this.lbl09.Name = "lbl09";
            this.lbl09.Size = new System.Drawing.Size(32, 13);
            this.lbl09.TabIndex = 8;
            this.lbl09.Text = "State";
            // 
            // lbl10
            // 
            this.lbl10.AutoSize = true;
            this.lbl10.Location = new System.Drawing.Point(21, 265);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(22, 13);
            this.lbl10.TabIndex = 9;
            this.lbl10.Text = "Zip";
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.Location = new System.Drawing.Point(21, 292);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(79, 13);
            this.lbl11.TabIndex = 10;
            this.lbl11.Text = "Expiration Date";
            // 
            // txtBx01
            // 
            this.txtBx01.Location = new System.Drawing.Point(147, 28);
            this.txtBx01.Name = "txtBx01";
            this.txtBx01.Size = new System.Drawing.Size(120, 20);
            this.txtBx01.TabIndex = 11;
            this.txtBx01.TextChanged += new System.EventHandler(this.txtBx01_TextChanged);
            // 
            // txtBx02
            // 
            this.txtBx02.Location = new System.Drawing.Point(148, 178);
            this.txtBx02.Name = "txtBx02";
            this.txtBx02.Size = new System.Drawing.Size(120, 20);
            this.txtBx02.TabIndex = 12;
            // 
            // txtBx03
            // 
            this.txtBx03.Location = new System.Drawing.Point(148, 208);
            this.txtBx03.Name = "txtBx03";
            this.txtBx03.Size = new System.Drawing.Size(120, 20);
            this.txtBx03.TabIndex = 13;
            // 
            // txtBx04
            // 
            this.txtBx04.Location = new System.Drawing.Point(148, 235);
            this.txtBx04.Name = "txtBx04";
            this.txtBx04.Size = new System.Drawing.Size(120, 20);
            this.txtBx04.TabIndex = 14;
            // 
            // txtBx05
            // 
            this.txtBx05.Location = new System.Drawing.Point(148, 262);
            this.txtBx05.Name = "txtBx05";
            this.txtBx05.Size = new System.Drawing.Size(120, 20);
            this.txtBx05.TabIndex = 15;
            // 
            // txtBx06
            // 
            this.txtBx06.Location = new System.Drawing.Point(148, 289);
            this.txtBx06.Name = "txtBx06";
            this.txtBx06.Size = new System.Drawing.Size(120, 20);
            this.txtBx06.TabIndex = 16;
            // 
            // chkBx01
            // 
            this.chkBx01.AutoSize = true;
            this.chkBx01.Location = new System.Drawing.Point(147, 104);
            this.chkBx01.Name = "chkBx01";
            this.chkBx01.Size = new System.Drawing.Size(15, 14);
            this.chkBx01.TabIndex = 17;
            this.chkBx01.UseVisualStyleBackColor = true;
            // 
            // chkBx02
            // 
            this.chkBx02.AutoSize = true;
            this.chkBx02.Location = new System.Drawing.Point(148, 130);
            this.chkBx02.Name = "chkBx02";
            this.chkBx02.Size = new System.Drawing.Size(15, 14);
            this.chkBx02.TabIndex = 18;
            this.chkBx02.UseVisualStyleBackColor = true;
            // 
            // chkBx03
            // 
            this.chkBx03.AutoSize = true;
            this.chkBx03.Location = new System.Drawing.Point(148, 152);
            this.chkBx03.Name = "chkBx03";
            this.chkBx03.Size = new System.Drawing.Size(15, 14);
            this.chkBx03.TabIndex = 19;
            this.chkBx03.UseVisualStyleBackColor = true;
            // 
            // comboBox01
            // 
            this.comboBox01.FormattingEnabled = true;
            this.comboBox01.Items.AddRange(new object[] {
            "F",
            "I",
            "R"});
            this.comboBox01.Location = new System.Drawing.Point(147, 51);
            this.comboBox01.Name = "comboBox01";
            this.comboBox01.Size = new System.Drawing.Size(121, 21);
            this.comboBox01.TabIndex = 20;
            // 
            // comboBox02
            // 
            this.comboBox02.FormattingEnabled = true;
            this.comboBox02.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10+"});
            this.comboBox02.Location = new System.Drawing.Point(147, 77);
            this.comboBox02.Name = "comboBox02";
            this.comboBox02.Size = new System.Drawing.Size(121, 21);
            this.comboBox02.TabIndex = 21;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(221, 324);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(103, 39);
            this.btnSubmit.TabIndex = 22;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // lbl12
            // 
            this.lbl12.AutoSize = true;
            this.lbl12.Location = new System.Drawing.Point(26, 23);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(54, 13);
            this.lbl12.TabIndex = 0;
            this.lbl12.Text = "Person ID";
            // 
            // lbl13
            // 
            this.lbl13.AutoSize = true;
            this.lbl13.Location = new System.Drawing.Point(26, 49);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(78, 13);
            this.lbl13.TabIndex = 1;
            this.lbl13.Text = "Membership ID";
            // 
            // lbl14
            // 
            this.lbl14.AutoSize = true;
            this.lbl14.Location = new System.Drawing.Point(26, 75);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(57, 13);
            this.lbl14.TabIndex = 2;
            this.lbl14.Text = "First Name";
            // 
            // lbl15
            // 
            this.lbl15.AutoSize = true;
            this.lbl15.Location = new System.Drawing.Point(26, 101);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(58, 13);
            this.lbl15.TabIndex = 3;
            this.lbl15.Text = "Last Name";
            // 
            // lbl16
            // 
            this.lbl16.AutoSize = true;
            this.lbl16.Location = new System.Drawing.Point(26, 127);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(73, 13);
            this.lbl16.TabIndex = 4;
            this.lbl16.Text = "Email Address";
            // 
            // lbl17
            // 
            this.lbl17.AutoSize = true;
            this.lbl17.Location = new System.Drawing.Point(26, 153);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(78, 13);
            this.lbl17.TabIndex = 5;
            this.lbl17.Text = "Phone Number";
            // 
            // lbl18
            // 
            this.lbl18.AutoSize = true;
            this.lbl18.Location = new System.Drawing.Point(26, 178);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(69, 13);
            this.lbl18.TabIndex = 6;
            this.lbl18.Text = "Active Child?";
            // 
            // lbl19
            // 
            this.lbl19.AutoSize = true;
            this.lbl19.Location = new System.Drawing.Point(26, 204);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(63, 13);
            this.lbl19.TabIndex = 7;
            this.lbl19.Text = "Year Joined";
            // 
            // lbl20
            // 
            this.lbl20.AutoSize = true;
            this.lbl20.Location = new System.Drawing.Point(26, 230);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(131, 13);
            this.lbl20.TabIndex = 8;
            this.lbl20.Text = "Emergency Contact Name";
            // 
            // lbl21
            // 
            this.lbl21.AutoSize = true;
            this.lbl21.Location = new System.Drawing.Point(26, 256);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(140, 13);
            this.lbl21.TabIndex = 9;
            this.lbl21.Text = "Emergency Contact Number";
            // 
            // lbl22
            // 
            this.lbl22.AutoSize = true;
            this.lbl22.Location = new System.Drawing.Point(26, 282);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(102, 13);
            this.lbl22.TabIndex = 10;
            this.lbl22.Text = "Emergency Relation";
            // 
            // lbl23
            // 
            this.lbl23.AutoSize = true;
            this.lbl23.Location = new System.Drawing.Point(26, 307);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(61, 13);
            this.lbl23.TabIndex = 11;
            this.lbl23.Text = "Birth Month";
            // 
            // lbl24
            // 
            this.lbl24.AutoSize = true;
            this.lbl24.Location = new System.Drawing.Point(26, 334);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(54, 13);
            this.lbl24.TabIndex = 12;
            this.lbl24.Text = "Birth Date";
            // 
            // lbl25
            // 
            this.lbl25.AutoSize = true;
            this.lbl25.Location = new System.Drawing.Point(26, 358);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(34, 13);
            this.lbl25.TabIndex = 13;
            this.lbl25.Text = "Digs?";
            // 
            // txtBx07
            // 
            this.txtBx07.Location = new System.Drawing.Point(176, 20);
            this.txtBx07.Name = "txtBx07";
            this.txtBx07.Size = new System.Drawing.Size(120, 20);
            this.txtBx07.TabIndex = 17;
            // 
            // txtBx08
            // 
            this.txtBx08.Location = new System.Drawing.Point(176, 46);
            this.txtBx08.Name = "txtBx08";
            this.txtBx08.Size = new System.Drawing.Size(120, 20);
            this.txtBx08.TabIndex = 18;
            // 
            // txtBx09
            // 
            this.txtBx09.Location = new System.Drawing.Point(176, 72);
            this.txtBx09.Name = "txtBx09";
            this.txtBx09.Size = new System.Drawing.Size(120, 20);
            this.txtBx09.TabIndex = 19;
            // 
            // txtBx10
            // 
            this.txtBx10.Location = new System.Drawing.Point(176, 98);
            this.txtBx10.Name = "txtBx10";
            this.txtBx10.Size = new System.Drawing.Size(120, 20);
            this.txtBx10.TabIndex = 20;
            // 
            // txtBx11
            // 
            this.txtBx11.Location = new System.Drawing.Point(176, 124);
            this.txtBx11.Name = "txtBx11";
            this.txtBx11.Size = new System.Drawing.Size(120, 20);
            this.txtBx11.TabIndex = 21;
            // 
            // txtBx12
            // 
            this.txtBx12.Location = new System.Drawing.Point(176, 150);
            this.txtBx12.Name = "txtBx12";
            this.txtBx12.Size = new System.Drawing.Size(120, 20);
            this.txtBx12.TabIndex = 22;
            // 
            // txtBx13
            // 
            this.txtBx13.Location = new System.Drawing.Point(176, 201);
            this.txtBx13.Name = "txtBx13";
            this.txtBx13.Size = new System.Drawing.Size(120, 20);
            this.txtBx13.TabIndex = 23;
            // 
            // txtBx14
            // 
            this.txtBx14.Location = new System.Drawing.Point(176, 227);
            this.txtBx14.Name = "txtBx14";
            this.txtBx14.Size = new System.Drawing.Size(120, 20);
            this.txtBx14.TabIndex = 24;
            // 
            // txtBx16
            // 
            this.txtBx16.Location = new System.Drawing.Point(176, 279);
            this.txtBx16.Name = "txtBx16";
            this.txtBx16.Size = new System.Drawing.Size(120, 20);
            this.txtBx16.TabIndex = 25;
            // 
            // txtBx15
            // 
            this.txtBx15.Location = new System.Drawing.Point(176, 253);
            this.txtBx15.Name = "txtBx15";
            this.txtBx15.Size = new System.Drawing.Size(120, 20);
            this.txtBx15.TabIndex = 26;
            // 
            // checkBox04
            // 
            this.checkBox04.AutoSize = true;
            this.checkBox04.Location = new System.Drawing.Point(176, 177);
            this.checkBox04.Name = "checkBox04";
            this.checkBox04.Size = new System.Drawing.Size(15, 14);
            this.checkBox04.TabIndex = 27;
            this.checkBox04.UseVisualStyleBackColor = true;
            // 
            // checkBox05
            // 
            this.checkBox05.AutoSize = true;
            this.checkBox05.Location = new System.Drawing.Point(176, 357);
            this.checkBox05.Name = "checkBox05";
            this.checkBox05.Size = new System.Drawing.Size(15, 14);
            this.checkBox05.TabIndex = 28;
            this.checkBox05.UseVisualStyleBackColor = true;
            // 
            // comboBox03
            // 
            this.comboBox03.FormattingEnabled = true;
            this.comboBox03.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12"});
            this.comboBox03.Location = new System.Drawing.Point(175, 304);
            this.comboBox03.Name = "comboBox03";
            this.comboBox03.Size = new System.Drawing.Size(121, 21);
            this.comboBox03.TabIndex = 29;
            // 
            // comboBox04
            // 
            this.comboBox04.FormattingEnabled = true;
            this.comboBox04.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.comboBox04.Location = new System.Drawing.Point(175, 331);
            this.comboBox04.Name = "comboBox04";
            this.comboBox04.Size = new System.Drawing.Size(121, 21);
            this.comboBox04.TabIndex = 30;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 456);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.newMembership.ResumeLayout(false);
            this.newMembership.PerformLayout();
            this.newPerson.ResumeLayout(false);
            this.newPerson.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage newMembership;
        private System.Windows.Forms.Label lbl08;
        private System.Windows.Forms.Label lbl07;
        private System.Windows.Forms.Label lbl06;
        private System.Windows.Forms.Label lbl05;
        private System.Windows.Forms.Label lbl04;
        private System.Windows.Forms.Label lbl03;
        private System.Windows.Forms.Label lbl02;
        private System.Windows.Forms.Label lbl01;
        private System.Windows.Forms.TabPage newPerson;
        private System.Windows.Forms.TabPage dueMeetingReport;
        private System.Windows.Forms.TabPage meetingReport;
        private System.Windows.Forms.TabPage rosterReport;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.ComboBox comboBox02;
        private System.Windows.Forms.ComboBox comboBox01;
        private System.Windows.Forms.CheckBox chkBx03;
        private System.Windows.Forms.CheckBox chkBx02;
        private System.Windows.Forms.CheckBox chkBx01;
        private System.Windows.Forms.TextBox txtBx06;
        private System.Windows.Forms.TextBox txtBx05;
        private System.Windows.Forms.TextBox txtBx04;
        private System.Windows.Forms.TextBox txtBx03;
        private System.Windows.Forms.TextBox txtBx02;
        private System.Windows.Forms.TextBox txtBx01;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Label lbl09;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Label lbl24;
        private System.Windows.Forms.Label lbl23;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Label lbl20;
        private System.Windows.Forms.Label lbl19;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.ComboBox comboBox04;
        private System.Windows.Forms.ComboBox comboBox03;
        private System.Windows.Forms.CheckBox checkBox05;
        private System.Windows.Forms.CheckBox checkBox04;
        private System.Windows.Forms.TextBox txtBx15;
        private System.Windows.Forms.TextBox txtBx16;
        private System.Windows.Forms.TextBox txtBx14;
        private System.Windows.Forms.TextBox txtBx13;
        private System.Windows.Forms.TextBox txtBx12;
        private System.Windows.Forms.TextBox txtBx11;
        private System.Windows.Forms.TextBox txtBx10;
        private System.Windows.Forms.TextBox txtBx09;
        private System.Windows.Forms.TextBox txtBx08;
        private System.Windows.Forms.TextBox txtBx07;
    }
}

