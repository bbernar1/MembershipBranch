﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JGMSNewMemberSignup
{
    public partial class Form1 : Form
    {
        int memberID, numberOfAdults, memberZip;
        string memberType, memberStreet, memberCity, memberState, expirationDate; 
        bool liabilityWaiver, confidentialAgreement, newsletterEmail;


        public Form1()
        {
            InitializeComponent();
            
        }

        private void lbl1_Click(object sender, EventArgs e)
        {

        }

        private void lbl2_Click(object sender, EventArgs e)
        {

        }

        private void txtBx01_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {

        }
    }
}
